﻿using System;
using System.Collections.Generic;


namespace DomoticaPrototipo
{
    public enum TipoParametro
    {
        String,
        Int,
        Double,
        Boolean,
        Date,
        Void,
        Stream
    }
}
