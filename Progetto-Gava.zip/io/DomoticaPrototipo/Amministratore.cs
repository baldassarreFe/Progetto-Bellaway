﻿using System;


namespace DomoticaPrototipo
{
    public class Amministratore : Utente
    {
        public Amministratore(string username, string nome, string password)
            : base(username, nome, password)
        {

        }
    }
}
