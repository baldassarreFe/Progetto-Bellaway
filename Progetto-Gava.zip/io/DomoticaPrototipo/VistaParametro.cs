﻿using System;
using System.Collections.Generic;


namespace DomoticaPrototipo
{
    public enum VistaParametro
    {
        TextBox,
        Button,
        ComboBox,
        RadioButton,
        CheckBox,
        TimerBox,
        DropList,
        Cursor
    }
}
